package swampMaster2160.lib.test;

//import swampMaster2160.lib.text.SMChar8;
//import swampMaster2160.lib.text.SMString8;

public class Main {
	public static void main(String[] args) {
		
		//SMString8 a = new SMString8("A Test tt A");
		//SMChar8 b = new SMChar8('B');
		
		//char b = a.charAt(0);
		
		//System.out.println(b.toString());
		
		//System.out.println(b);
		
		/*for(int i = 0; i < a.length(); i++) {
			System.out.println(a.charAt(i));
		}*/
		
		/*for(int i = 0x00; i < 0x100; i++) {
			char j = (char)i;
			System.out.print(j);
		}
		
		System.out.println();*/
		
		/*for(int i = 0x00; i < 0x100; i++) {
			SMChar8 k = new SMChar8((byte)i);
			System.out.print(k.toChar());
		}
		
		System.out.println();
		
		for(int i = 0x00; i < 0x100; i++) {
			SMChar8 k = new SMChar8((byte)i);
			System.out.print(k.toCharAll());
		}*/
		
		/*System.out.println();
		
		for(int i = 0x00; i < 0x100; i++) {
			char j = (char)i;
			System.out.print(new SMChar8(j).toChar());
		}*/
		//System.out.println((char)0x1F);
	}
}
