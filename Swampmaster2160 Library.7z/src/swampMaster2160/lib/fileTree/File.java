package swampMaster2160.lib.fileTree;

public class File {
	public String name;
	
	public File(String name) {
		this.name = name;
	}
}
